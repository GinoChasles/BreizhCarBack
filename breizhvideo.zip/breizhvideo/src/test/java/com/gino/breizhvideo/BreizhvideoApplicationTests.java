package com.gino.breizhvideo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BreizhvideoApplicationTests {

	@Test
	void contextLoads() {
	}

}
